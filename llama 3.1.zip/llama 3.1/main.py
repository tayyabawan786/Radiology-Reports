from data_preprocessing import DataPreprocessing
from model_setup import ModelSetup
from model_training import ModelTrainer
from explainability import Explainability
from datasets import Dataset

def main(filepath):
    # Step 1: Data Preprocessing
    data_prep = DataPreprocessing(filepath)
    df = data_prep.apply_preprocessing()
    df = data_prep.label_encoding()

    # Step 2: Split Data
    train_data = Dataset.from_pandas(df.sample(frac=0.8, random_state=42))  # 80% training data
    eval_data = Dataset.from_pandas(df.drop(train_data.index))  # Remaining 20% for evaluation

    # Step 3: Model Setup
    model_setup = ModelSetup(model_name='meta-llama/Llama-3.1-8B', output_dir='/trained_model_weights')
    model_setup.load_model()
    model_setup.load_tokenizer()
    model_setup.configure_peft()
    model_setup.set_training_arguments()

    # Step 4: Model Training
    model_trainer = ModelTrainer(model_setup, train_data, eval_data)
    model_trainer.train()
    model_trainer.evaluate()
    model_trainer.save_model()

    # Step 5: SHAP and LIME Explanations
    explainability = Explainability(model_setup.model, model_setup.tokenizer, df['text'].tolist())
    explainability.explain_with_shap()
    explainability.explain_with_lime()

if __name__ == "__main__":
    main("final_radiology_data.csv")
