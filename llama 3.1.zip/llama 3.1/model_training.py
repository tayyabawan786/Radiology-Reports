from datasets import Dataset
from trl import SFTTrainer

class ModelTrainer:
    def __init__(self, model_setup, train_data, eval_data):
        self.model_setup = model_setup
        self.train_data = train_data
        self.eval_data = eval_data
        self.trainer = None

    def train(self):
        self.trainer = SFTTrainer(
            model=self.model_setup.model,
            args=self.model_setup.training_arguments,
            train_dataset=self.train_data,
            eval_dataset=self.eval_data,
            peft_config=self.model_setup.peft_config,
            dataset_text_field="text",
            tokenizer=self.model_setup.tokenizer,
            max_seq_length=512,
        )
        self.trainer.train()

    def evaluate(self):
        self.trainer.evaluate()

    def save_model(self):
        self.trainer.save_model()
        self.model_setup.tokenizer.save_pretrained(self.model_setup.output_dir)
