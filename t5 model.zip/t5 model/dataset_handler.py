# src/dataset_handler.py

import pandas as pd
from datasets import Dataset, DatasetDict
from sklearn.model_selection import train_test_split

class DatasetHandler:
    def __init__(self, filepath, preprocess_fn):
        self.data = pd.read_csv(filepath)
        self.preprocessor = preprocess_fn
        self.dataset = None

    def prepare_data(self):
        self.data.dropna(inplace=True)
        self.data.drop_duplicates(inplace=True)
        self.data['text'] = self.data['fulltext'].apply(self.preprocessor)
        self.data.drop('fulltext', axis=1, inplace=True)

    def map_labels(self):
        category_mapping = {'normal': 1, 'abnormal': 0}
        self.data['label'] = self.data['label'].replace(category_mapping)

    def split_data(self):
        train_df, test_df = train_test_split(self.data.sample(frac=1, random_state=42).reset_index(drop=True), test_size=0.2, random_state=42)
        train_dataset = Dataset.from_pandas(train_df)
        test_dataset = Dataset.from_pandas(test_df)

        self.dataset = DatasetDict({
            'train': train_dataset,
            'test': test_dataset
        })

        self.dataset['train'] = self.dataset['train'].remove_columns('__index_level_0__')
        self.dataset['test'] = self.dataset['test'].remove_columns('__index_level_0__')
        return self.dataset
