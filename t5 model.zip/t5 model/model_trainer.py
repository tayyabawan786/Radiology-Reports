
import torch
from datasets import concatenate_datasets
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, DataCollatorForSeq2Seq, Seq2SeqTrainer, Seq2SeqTrainingArguments
import evaluate
import numpy as np
from nltk import sent_tokenize
from tqdm import tqdm
from sklearn.metrics import classification_report

class ModelTrainer:
    def __init__(self, dataset, model_id="google/flan-t5-base"):
        self.dataset = dataset
        self.model_id = model_id
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_id)
        self.max_source_length = 0
        self.max_target_length = 0
        self.tokenized_dataset = None
        self.metric = evaluate.load("f1")

    def compute_max_lengths(self):
        tokenized_inputs = concatenate_datasets([self.dataset["train"], self.dataset["test"]]).map(lambda x: self.tokenizer(x["text"], truncation=True), batched=True, remove_columns=['text', 'label'])
        self.max_source_length = max([len(x) for x in tokenized_inputs["input_ids"]])

        tokenized_targets = concatenate_datasets([self.dataset["train"], self.dataset["test"]]).map(lambda x: self.tokenizer(x["label"], truncation=True), batched=True, remove_columns=['text', 'label'])
        self.max_target_length = max([len(x) for x in tokenized_targets["input_ids"]])

    def preprocess_function(self, sample, padding="max_length"):
        inputs = [item for item in sample["text"]]
        model_inputs = self.tokenizer(inputs, max_length=self.max_source_length, padding=padding, truncation=True)

        labels = self.tokenizer(text_target=sample["label"], max_length=self.max_target_length, padding=padding, truncation=True)
        if padding == "max_length":
            labels["input_ids"] = [(l if l != self.tokenizer.pad_token_id else -100) for label in labels["input_ids"]]
        model_inputs["labels"] = labels["input_ids"]
        return model_inputs

    def tokenize_dataset(self):
        self.tokenized_dataset = self.dataset.map(self.preprocess_function, batched=True, remove_columns=['text', 'label'])

    def postprocess_text(self, preds, labels):
        preds = [pred.strip() for pred in preds]
        labels = [label.strip() for label in labels]
        preds = ["\n".join(sent_tokenize(pred)) for pred in preds]
        labels = ["\n".join(sent_tokenize(label)) for label in labels]
        return preds, labels

    def compute_metrics(self, eval_preds):
        preds, labels = eval_preds
        if isinstance(preds, tuple):
            preds = preds[0]
        decoded_preds = self.tokenizer.batch_decode(preds, skip_special_tokens=True)
        labels = np.where(labels != -100, labels, self.tokenizer.pad_token_id)
        decoded_labels = self.tokenizer.batch_decode(labels, skip_special_tokens=True)
        decoded_preds, decoded_labels = self.postprocess_text(decoded_preds, decoded_labels)

        result = self.metric.compute(predictions=decoded_preds, references=decoded_labels, average='macro')
        result = {k: round(v * 100, 4) for k, v in result.items()}
        return result

    def train(self):
        label_pad_token_id = -100
        data_collator = DataCollatorForSeq2Seq(self.tokenizer, model=self.model, label_pad_token_id=label_pad_token_id, pad_to_multiple_of=8)

        training_args = Seq2SeqTrainingArguments(
            output_dir="flan-t5-model",
            per_device_train_batch_size=8,
            per_device_eval_batch_size=8,
            predict_with_generate=True,
            fp16=False,
            learning_rate=2e-4,
            num_train_epochs=3,
            logging_dir="flan-t5-model/logs",
            logging_strategy="epoch",
            evaluation_strategy="no",
            save_strategy="epoch",
            save_total_limit=2,
            load_best_model_at_end=False,
            report_to="tensorboard",
            push_to_hub=False,
        )

        trainer = Seq2SeqTrainer(
            model=self.model,
            args=training_args,
            data_collator=data_collator,
            train_dataset=self.tokenized_dataset["train"],
            eval_dataset=self.tokenized_dataset["test"],
            compute_metrics=self.compute_metrics
        )

        trainer.train()
        trainer.evaluate()

    def evaluate_predictions(self):
        predictions_list = []
        labels_list = []
        progress_bar = tqdm(range(len(self.dataset['test'])))

        for i in range(len(self.dataset['test'])):
            text = self.dataset['test']['text'][i]
            inputs = self.tokenizer.encode_plus(text, padding='max_length', max_length=512, return_tensors='pt').to('cuda')
            outputs = self.model.generate(inputs['input_ids'], attention_mask=inputs['attention_mask'], max_length=150, num_beams=2, early_stopping=True)
            prediction = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            predictions_list.append(prediction)
            labels_list.append(self.dataset['test']['label'][i])
            progress_bar.update(1)

        report = classification_report(labels_list, predictions_list)
        print(report)
